# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['test_grader_opencv']

package_data = \
{'': ['*']}

install_requires = \
['imutils>=0.5.3,<0.6.0',
 'numpy>=1.18.1,<2.0.0',
 'opencv-contrib-python>=4.1.2,<5.0.0',
 'pillow>=7.0.0,<8.0.0',
 'scikit-image>=0.16.2,<0.17.0',
 'tensorflow-gpu>=2.1.0,<3.0.0']

setup_kwargs = {
    'name': 'test-grader-opencv',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Valentino Vizner',
    'author_email': 'valentino.vizner@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
